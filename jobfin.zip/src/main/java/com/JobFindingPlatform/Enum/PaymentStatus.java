package com.JobFindingPlatform.Enum;

public enum PaymentStatus {
	SUCCESS,FAILED,PENDING
}
