package com.JobFindingPlatform.Enum;

public enum PlanName {
	FREE,BASIC,PREMIUM
}
