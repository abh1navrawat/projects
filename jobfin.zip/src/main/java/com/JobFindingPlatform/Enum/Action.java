package com.JobFindingPlatform.Enum;

public enum Action {
BLOCK, UNBLOCK
}
