package com.JobFindingPlatform.Enum;

public enum Role {
	JOBSEEKER,ADMIN,RECRUITER
}
