package com.JobFindingPlatform.Enum;

public enum ApplicationStatus {
ACCEPTED,REJECTED,SHORTLISTED
}
