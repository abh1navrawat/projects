package com.JobFindingPlatform.Enum;

public enum JobType {
	INTERNSHIP, EXPERIENCED
}
