package com.JobFindingPlatform.Enum;

public enum Duration {
	MONTHLY,QUATERLY,YEARLY
}
